# Shopping-web-Jsp-Servlet
Course project use Jsp and Servlet to create Shopping website. <br/>
Basic project, not use ajax. I'll update it.
